#!/usr/bin/env python
# coding: utf-8

# ### NumPy Exercises
# ##### Now that we've learned about NumPy let's test your knowledge. We'll start off with a few simple tasks and then you'll be asked some more complicated questions.
# ##### IMPORTANT NOTE! Make sure you don't run the cells directly above the example output shown, otherwise you will end up writing over the example output!

# ##### import numpy as np
# 

# ###### 1. Write a NumPy program to find the missing data in a given array.

# In[2]:


### code here
import numpy as np
x=np.array([[3,2,np.nan,1],
            [10,12,10,9],
            [5,np.nan,1,np.nan]])
print("Original array:")
print(x)
print("\nFind the missing data of the said array:")
print(np.isnan(x))


# In[ ]:


## sample output


# ##### 2. Write a NumPy program to check whether two arrays are equal (element wise) or not.

# In[43]:


import numpy as np
x=list(input("enter value"))
a=np.array(x)
y=list(input("enter value"))
b=np.array(y)
print(np.array_equal(a,b))
k=list(input("enter value"))
i=np.array(k)
l=list(input("enter value"))
j=np.array(l)
print(np.array_equal(i,j))


# In[ ]:





# ###### 3. Write a NumPy program to create a 4x4 array with random values, now create a new array from the said array swapping first and last rows.

# In[55]:


## code here
import numpy as np 
nums = np.arange(16, dtype='int').reshape(4, 4)
print("Original array:")
print(nums)
print("\nNew array after swapping first and last columns of the said array:")
n = nums[:, ::-1]
x=np.flip(n)
print(x)


# In[ ]:


## sample output


# ###### 4. Write a NumPy program to convert a list and tuple into arrays.

# In[61]:


#### code here
import numpy as np
x=[1,2,3,4,5]
print (" Here the 'x' is a list",x)  ## x is a list
print(x)
z=np.array(x)
print("after passing  a list into the array it will be convert into array object",z)
print(z)


# ###### 5. Write a NumPy program to find common values between two arrays.

# In[45]:


### code here
import numpy as np
x=np.array([1,2,3])
y=np.array([10,2,13])
print(np.intersect1d(x,y))


# ###### 6. Write a NumPy program to create a new shape to an array without changing its data.

# In[59]:


### code here
import numpy as np
x=np.array([1,2,3,4,5,6])
print("Reshape 3x2:")
print(x.reshape(3,2))
print("Reshape 2x3:")
print(x.reshape(2,3))


# In[ ]:


### sample output


# ###### 7. Write a NumPy program to count the frequency of unique values in numpy array.

# In[68]:


### code here
import numpy as np
a = np.array( [10,10,20,10,20,20,20,30, 30,50,40,40] )
print("Original array:")
print(a)
unique_elements, counts_elements = np.unique(a, return_counts=True)
print("Frequency of unique values of the said array:")
print(np.asarray((unique_elements, counts_elements)))


# In[ ]:


## sample output


# ###### 8. Write a NumPy program to broadcast on different shapes of arrays where p(3,3) + q(3).

# In[79]:


### code here
import numpy as np
x=np.array([[0,0,0],
            [1,2,3],
            [4,5,6]])
print("Original arrays:")
print("Array-1")
print(x)
y=np.array([10,11,12])
print("Array-2")
print(y)
print("\nNew Array:")
z=sum((x,y))
print(z)


# In[ ]:


## sample output


# ###### 9. Write a NumPy program to extract all the elements of the second row from a given (4x4) array.

# In[3]:


### code hereimport numpy as np
arra_data = np.arange(0,16).reshape((4, 4))
print("Original array:")
print(arra_data)
print("\nExtracted data: Second row")
print(arra_data[1,:])


# In[ ]:





# ###### 10. Write a NumPy program to extract third and fourth elements of the first and second rows from a given (4x4) array.

# In[7]:


## code here
import numpy as np
x=np.array([[0,1,2,3],
            [4,5,6,7],
            [8,9,10,11],
            [12,13,14,15]])
print("Original array:")
print(x)
print("Extracted data:Third and fourth element of the first and second rows")
print(x[0:2,2:4])


# In[ ]:


## sample output


# ###### 11. Write a NumPy program to get the dates of yesterday, today and tomorrow.

# In[50]:


### code here
import numpy as np
yesterday = np.datetime64('today', 'D') - np.timedelta64(1, 'D')
print("yestraday: ",yesterday)
today     = np.datetime64('today', 'D')
print("today: ",today)
tomorrow  = np.datetime64('today', 'D') + np.timedelta64(1, 'D')
print("tomorrow: ",tomorrow)


# ###### 12. Write a NumPy program to find the first Monday in May 2017.

# In[9]:


## code here
import numpy as np
print("First Monday in May 2017:")
print(np.busday_offset("2017-05",0,roll="forward",weekmask="Mon"))


# In[ ]:


## sample output


# In[ ]:




